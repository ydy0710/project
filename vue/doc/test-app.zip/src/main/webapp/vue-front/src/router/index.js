import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld,
    },
    {path: '/axios-1', name: 'axios-1', component: ()=> import ('../components/example/axios/Axios-1.vue')},
    {path: '/axios-2', name: 'axios-2', component: ()=> import ('../components/example/axios/Axios-2.vue')},
    {path: '/axios-3', name: 'axios-3', component: ()=> import ('../components/example/axios/Axios-3.vue')},
    {path: '/parent-1', name: 'parent-1', component: ()=> import ('../components/example/passing-data/Parent-1.vue')},
    {path: '/parent-2', name: 'parent-2', component: ()=> import ('../components/example/passing-data/Parent-2.vue')},
    {path: '/parent-3', name: 'parent-3', component: ()=> import ('../components/example/passing-data/Parent-3.vue')},
    {path: '/parent-4', name: 'parent-4', component: ()=> import ('../components/example/passing-data/Parent-4.vue')}
  ]
})
