<template>
    <div class="parent-area">
        <h3>Parent-3.vue</h3>
        <pre align="left">
        Event Bus에 대한 예시입니다.

        여기서 Parent-4 상위 컴포넌트는 Children-6, Children-7을 실행하기 위한 백그라운드 페이지 역할만 합니다.
        Children-6, Children-7 사이의 데이터 전달은 전역 Event Bus로 만들어진 비어있는 vue 객체가 담당합니다.
        </pre>
        <div>
            <children-6 @sendMsg="receivedMsg"></children-6>
        </div>
        <p>receivedMsg: <span>{{message}}</span></p>
        <div>
            <children-7 :propsMsg="message"></children-7>
        </div>
    </div>
</template>

<script>
import Children6 from './childrens/Children-6.vue'
import Children7 from './childrens/Children-7.vue'

export default {
    components: {
        'children-6': Children6,
        'children-7': Children7,
    },
    data(){
        return {
            message: ''
        }
    },
    methods: {
        receivedMsg: function(val){
            this.message = val;
        }
    }
}
</script>