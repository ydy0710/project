<!--
본 예시는 config > index.js의 proxy 설정 이후 axios 통신을 보여줍니다.
axios 통신에 성공할 경우 data의 user에 데이터를 셋팅합니다.
-->

<template>
    <div>
        <h3>axios-2</h3>
        <button @click="getTest">click</button>
        <button @click="reset">reset</button>
        <h3>name: {{user.name}}</h3>
        <h3>company: {{user.company}}</h3>
    </div>
</template>

<script>


export default {
    data(){
        return {
            user: {
                name: '',
                company: '',
            }
        }
    },
    methods: {
        getTest: function(){
            // this = vm(vue 인스턴스)
            this.$axios.get('/api/example/axios-2').then((resp)=>{
                if(resp.data){
                    this.user.name = '조승은';
                    this.user.company = 'sehyun ict';
                }
            }).catch((error)=>{
                console.log(error);
            });
        },
        reset: function(){
            this.user.name = '';
            this.user.company = '';
        }
    }
}
</script>