<template>
  <div id="app">
    <img src="./assets/logo.png">
    <example-menu></example-menu>
    <router-view/>
  </div>
</template>

<script>
import ExampleMenu from './components/ExampleMenu.vue'

export default {
  name: 'App',
  components: {
    'example-menu': ExampleMenu
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

/* custom 전역 스타일 */
.parent-area {
    width: calc(100% - 5px);
    height: calc(100% - 5px);
    border: 1px black solid;
}
.children-area {
    width: 500px;
    height: 200px;
    border: 1px black solid;
    text-align: left;
    padding: 10px;
}
</style>
