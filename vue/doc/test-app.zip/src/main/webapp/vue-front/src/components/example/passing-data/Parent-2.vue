<template>
    <div class="parent-area">
        <h3>Parent-2.vue</h3>
        <pre align="left">
        본 Parent-2은 상위 컴포넌트(부모 컴포넌트) 입니다.
        
        'sendEvent'라는 이벤트명으로 하위 컴포넌트(자식 컴포넌트)의 이벤트를 수신합니다.
        
        Children-3
         - click 이벤트를 'sendMsg'라는 이름으로 전달합니다.
        </pre>
        <div>
            <children-3 @sendEvent="receivedEvent"></children-3>
        </div>
        <p>receivedEvent: <span>{{messgae}}</span></p>
        
        <!-- event에 data를 함께 전달하는 예제입니다. 주석을 해제하여 테스트할 수 있습니다. -->
        <!-- <div>
            <children-3 @sendMsg="receivedMsg"></children-3>
        </div>
        <p>receivedMsg: <span>{{messgae}}</span></p> -->
    </div>
</template>

<script>
import Children3 from './childrens/Children-3.vue'

export default {
    components: {
        'children-3': Children3,
    },
    data(){
        return {
            messgae: ''
        }
    },
    methods: {
        receivedEvent: function(){
            this.messgae = "event 수신 완료";
        }
        // receivedMsg: function(val){
        //     this.messgae = val;
        // }
    }
}
</script>