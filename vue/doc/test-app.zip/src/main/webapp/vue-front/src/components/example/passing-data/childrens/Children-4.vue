<template>
    <div class="children-area">
        <h3>Children-4.vue</h3>
        <input v-model="message"/>
        <button @click="sendMsg">Send To Parent-3</button> <!-- v-on:click의 약어 형태 -->
    </div>
</template>

<script>
export default {
    data(){
        return { 
            message: ''
        }
    },
    methods: {
        sendMsg: function(){
            this.$emit('sendMsg', this.message);
        }
    }
}
</script>