<template>
    <div class="parent-area">
        <h3>Parent-3.vue</h3>
        <pre align="left">
        본 Parent-3은 상위 컴포넌트(부모 컴포넌트) 입니다.
        
        앞선 Parent-1, Parent-2 예시를 통합한 것으로,
        Children-4, Children-5 형제 컴포넌트(비 부모자식) 간의 데이터 전달에 적용할 수 있습니다.

        'Children-4 (event) -> Parent-3 (props) -> Children-5'의 순서로 데이터 전달이 이루어집니다.
        </pre>
        <div>
            <children-4 @sendMsg="receivedMsg"></children-4>
        </div>
        <p>receivedMsg: <span>{{message}}</span></p>
        <div>
            <children-5 :propsMsg="message"></children-5>
        </div>
    </div>
</template>

<script>
import Children4 from './childrens/Children-4.vue'
import Children5 from './childrens/Children-5.vue'

export default {
    components: {
        'children-4': Children4,
        'children-5': Children5,
    },
    data(){
        return {
            message: ''
        }
    },
    methods: {
        receivedMsg: function(val){
            this.message = val;
        }
    }
}
</script>