<template>
    <div>
        <div>
            <router-link to="/">HelloWorld</router-link>
        </div>
        <div>
            <router-link to="/axios-1">axios-1</router-link>
            <router-link to="/axios-2">axios-2</router-link>
            <router-link to="/axios-3">axios-3</router-link>
            <button v-on:click="goParent1">parent-1</button>
            <button v-on:click="goParent2">parent-2</button>
            <button v-on:click="goParent3">parent-3</button>
            <button v-on:click="goParent4">parent-4</button>
        </div>
    </div>
</template>

<script>
export default {
    methods: {
        goParent1: function(){
            this.$router.push({name: 'parent-1'});
        },
        goParent2: function(){
            this.$router.push({name: 'parent-2'});
        },
        goParent3: function(){
            this.$router.push({name: 'parent-3'});
        }
        ,
        goParent4: function(){
            this.$router.push({name: 'parent-4'});
        }
    }
}
</script>