<!--
Parent-1에서 보낸 'propsMsg'를 template에 직접적으로 바인딩 합니다.

상위 컴포넌트의 값이 변경될 경우 하위 컴포넌트의 값도 함께 변경됩니다.

'propsMsg'의 값을 수정할 수 없습니다.
<input>태그에 전달된 값을 임의로 수정할 때 개발자도구에서 오류를 확인할 수 있습니다.
-->

<template>
    <div class="children-area">
        <h3>Children-1.vue</h3>
        v-model을 사용한 propsMsg: <input v-model="propsMsg"/>
        <p>v-text를 사용한 propsMsg: <span v-text="propsMsg" /></p>
        <p>Mustache(이중 중괄호) propsMsg: {{propsMsg}}</p>
    </div>
</template>

<script>
export default {
    props: {
        propsMsg: {type: String, default: ''} //props 유효성 검사. 필수 X
                                              //컴포넌트 인스턴스(data)가 생성되기 전에 일어남
    },
    data(){
        return {
        
        }
    }
}
</script>

<style scoped>

</style>