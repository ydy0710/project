<!--
본 예시는 axios의 post 통신 예시입니다.
-->

<template>
    <div>
        <h3>axios-3</h3>
        <button @click="postTest">post test</button>
        <button @click="reset">reset</button>
        <input v-model="user.name"/>
        <input v-model="user.company"/>
        <h3>{{msg}}</h3>
        <h3>result: {{result}}</h3>
    </div>
</template>

<script>


export default {
    data(){
        return {
            user: {
                name: '',
                company: '',
            },
            msg: '',
            result: false
        }
    },
    methods: {
        postTest: function(){
            let param = {
                name: this.user.name,
                company: this.user.company
            }
            this.$axios.post('/api/example/axios-3', param).then((resp)=>{
                if(resp){
                    this.msg = "통신 완료";
                    this.result = resp.data;
                }
            }).catch((error)=>{
                console.log(error);
            });
        },
        reset: function(){
            this.user.name = '';
            this.user.company = '';
            this.msg='';
            this.result = false;
        }
    }
}
</script>