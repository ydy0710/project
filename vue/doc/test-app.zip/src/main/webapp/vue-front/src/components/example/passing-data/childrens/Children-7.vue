<template>
    <div class="children-area">
        <h3>Children-7.vue</h3>
        <p>message: <span>{{message}}</span></p>
    </div>
</template>

<script>
export default {
    data(){
        return { 
            message: ''
        }
    },
    created(){
        this.$bus.$on('sendMsg', function(val){
            this.message = val;
        }.bind(this));
    }
}
</script>