<!--
Parent-1에서 보낸 'propsMsg'를 local 변수에 바인딩합니다.

data 속성에 로컬 변수를 선언하고 'propsMsg'를 바인딩합니다.
'propsMsg'는 초기값으로만 사용되고 이후의 데이터 컨트롤은 로컬 변수를 사용합니다.

상위 컴포넌트의 값이 변경된 경우 하위 컴포넌트에서 인식하지 못합니다.
-->

<template>
    <div class="children-area">
        <h3>Children-2.vue</h3>
        <p>origin propsMsg: <span>{{propsMsg}}</span></p>
        content: <input v-model="content"/><br>
    </div>
</template>

<script>
export default {
    props: {
        propsMsg: {} 
    },
    data(){
        return { 
            content: this.propsMsg,
        }
    }
}
</script>

<style scoped>
</style>