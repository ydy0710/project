<template>
    <div class="children-area">
        <h3>Children-3.vue</h3>
        <button v-on:click="sendEvent">Send To Parent-2</button>
 
        <!-- event에 data를 함께 전달하는 예제입니다. 주석을 해제하여 테스트할 수 있습니다. -->
        <!-- <input v-model="message"/>
        <button v-on:click="sendMsg">Send To Parent-2</button> -->
    </div>
</template>

<script>
export default {
    data(){
        return { 
            message: ''
        }
    },
    methods: {
        sendEvent: function(){
            this.$emit('sendEvent');
        }
        // sendMsg: function(){
        //     this.$emit('sendMsg', this.message);
        // }
    }
}
</script>