<!--
본 예시는 axios를 이용한 서버 통신에서 CROS 이슈 발생을 보여줍니다.

사용자는 'localhost:3000'으로 접속합니다.
브라우저는 axios를 이용하여 서버의 'localhost:8080'으로 데이터를 요청합니다.
이 때, 브라우저는 CROS 정책(교차 출처 리소스 공유)에 따라 '요청측의 주소'와 '응답 측의 허용 주소'를 비교합니다.

이를 해결하기 위해 프론트엔드(vue project) 또는 백엔드(spring project)에서의 별도 설정이 필요합니다.
-->

<template>
    <div>
        <h3>axios-1</h3>
        <button @click="clickGet">click</button>
        <h3>name: {{user.name}}</h3>
        <h3>company: {{user.company}}</h3>
    </div>
</template>

<script>
export default {
    data(){
        return {
            user: {
                name: '',
                company: '',
            }
        }
    },
    methods: {
        clickGet: function(){
            this.$axios.get('http://localhost:8080/example/axios-1').then((resp)=>{
                if(resp==='SUCCESS'){
                    this.user.name = '조승은';
                    this.user.company = 'sehyun ict';
                }
            }).catch((error)=>{
                console.log(error);
            });
        }
    }
}
</script>
