<template>
    <div class="children-area">
    <h3>Children-5.vue</h3>
    <pre>
    상위 컴포넌트에서 전달받은 값을 로컬 변수에 바인딩했을 때, 변경된 값을 알 수 없습니다.(Children-2)
    
    watch 속성은 값의 '변경'을 감지하는 '감시자' 입니다.
    인자값으로 '새로운 값(n)'과 '이전 값(o)'을 갖습니다.
    특정 값에 대해 감시하고 있다가 값의 변화가 이루지는 순간 실행됩니다.
    </pre>
        <p>origin propsMsg: <span>{{propsMsg}}</span></p>
        watch content: <input v-model="content"/><br>
    </div>
</template>

<script>
export default {
    props: {
        propsMsg: {} 
    },
    watch: {
        propsMsg: function(n, o){
            this.content = n;
        }
    },
    data(){
        return { 
            content: this.propsMsg
        }
    }
}
</script>