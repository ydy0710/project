<template>
    <div class="parent-area">
        <h3>Parent-1.vue</h3>
        <pre align="left">
        본 Parent-1은 상위 컴포넌트(부모 컴포넌트) 입니다.

        'propsMsg'라는 이름으로 자신의 'message' 데이터를 하위 컴포넌트(자식 컴포넌트)에 보냅니다.
        이벤트가 없기 때문에 페이지 실행과 동시에 하위 컴포넌트로 데이터를 전달합니다.

        Children-1
         - 상위 컴포넌트의 값을 template에 직접 바인딩 합니다.
         - 상위 컴포넌트의 값이 변경된 경우 하위 컴포넌트도 함께 변경됩니다.
         - 전달받은 값을 하위 컴포넌트에서 수정할 수 없습니다.

        Children-2
         - 상위 컴포넌트의 값을 하위 컴포넌트의 로컬 변수에 바인딩 합니다.
         - 상위 컴포넌트의 값이 변경된 경우 하위 컴포넌트에서 이를 알지 못합니다.
         - 전달받은 값을 하위 컴포넌트에서 수정할 수 있습니다.
        </pre>
        <div>
            <p><input v-model="message"/></p>
            <children-1 v-bind:propsMsg="message"></children-1> <!-- v-bind:"변수명"="값" -->
            <children-2 :propsMsg="message"></children-2>       <!-- v-bind: 약어 사용 -->
        </div>
    </div>
</template>

<script>
import Children1 from './childrens/Children-1.vue'
import Children2 from './childrens/Children-2.vue'

export default {
    components: {
        'children-1': Children1,
        'children-2': Children2,
    },
    data(){
        return {
            message: 'children 전송'
        }
    },
}
</script>
<style scoped>

</style>