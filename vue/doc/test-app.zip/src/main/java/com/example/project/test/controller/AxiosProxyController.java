package com.example.project.test.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.test.entity.UserEntity;

/**
 * Vue.js의 axios 비동기 통신을 위한 Controller 입니다.
 */

@RestController
@RequestMapping("/api")
public class AxiosProxyController {
	
	/**
	 * axios-2.vue 통신 controller
	 * @return boolean result
	 */
	@GetMapping("/example/axios-2")
	public ResponseEntity<?> axiosGetTest(){
		boolean result = false;
		// 통신에 성공한 경우 true를 반환합니다.
		try{
			result = true;
		}catch(Exception e) {
			e.printStackTrace();
			result = false;
		}
		return ResponseEntity.ok(result);
	}
	
	/**
	 * axios-3.vue 통신 controller
	 * @param UserEntity user
	 * @return boolean result
	 * post 통신 예시 입니다. 디버그 모드의 break point로 데이터를 확인할 수 있습니다.
	 * 디버그 모드 실행: 프로젝트 우클릭 -> Debug As -> Spring Boot App
	 */
	@PostMapping("/example/axios-3")
	public ResponseEntity<?> postTest(@RequestBody UserEntity user){
		boolean result = true;
	    return ResponseEntity.ok(result);
	}
}
