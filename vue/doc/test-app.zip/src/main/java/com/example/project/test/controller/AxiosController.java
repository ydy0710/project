package com.example.project.test.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Vue.js의 axios 비동기 통신을 위한 Controller 입니다.
 */

@RestController
@RequestMapping("/")
public class AxiosController {
	
	/**
	 * axios-1.vue 통신 controller
	 * @return boolean result
	 */
	@GetMapping("/example/axios-1")
	public ResponseEntity<?> axiosGetTest(){
		String result = "FALSE";
		// 통신에 성공한 경우 true를 반환합니다.
		try{
			result = "SUCCESS";
		}catch(Exception e) {
			e.printStackTrace();
			result = "FALSE";
		}
		return ResponseEntity.ok(result);
	}
}
