// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// 사용할 컴포넌트 파일
import global from './components/globalComponent'

Vue.config.productionTip = false

//전역 컴포넌트 선언
Vue.component('global',global)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
