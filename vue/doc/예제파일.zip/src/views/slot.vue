<template>
    <div class = "about">
        <h1>{{ msg }}</h1>
        <test>
            <!-- slot 영역-->
            <template v-slot:header="props">
                <p>{{ props.myName }}</p>
            </template>
            <template v-slot:body>
                <p>바보</p>
            </template>
        </test>

        <test>
            <!-- slot 영역-->
            <!-- v-slot은 #으로 표현이 가능합니다. -->
            <template #header="props">
                <p>{{ props.myName }}</p>
            </template>
            <template #body>
                <p>바보</p>
            </template>
        </test>
    </div>
</template>

<script>
import test from '@/components/test.vue';

export default {
    components: {
        test
    },
    name: 'about',
    data () {
        return {
        msg: 'This is About page',
        title: 'About page title'
    }
  }
}
</script>

<style scoped>
h1 {
    color: blue;
}
</style>