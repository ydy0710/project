<template>
    <div>
        <h1>{{ title }}</h1>
        <router-link to="/views/sample/directive/textExample">v-text</router-link>
        <router-link to="/views/sample/directive/htmlExample">v-html</router-link>
        <router-link to="/views/sample/directive/showExample">v-show</router-link>
        <router-link to="/views/sample/directive/ifExample">v-if</router-link>
        <router-link to="/views/sample/directive/forExample">v-for</router-link>
        <router-link to="/views/sample/directive/bind/bindExample">v-bind1</router-link>
        <router-link to="/views/sample/directive/bind/bindExample2">v-bind2</router-link>
        <router-link to="/views/sample/directive/onceExample">v-once</router-link>
        <br>
        <router-link to="/views/sample/directive/on/onExample">v-on1</router-link>
        <router-link to="/views/sample/directive/on/onExample2">v-on2</router-link>
        <router-link to="/views/sample/directive/on/onExample3">v-on3</router-link>
        <router-link to="/views/sample/directive/on/onExample4">v-on4</router-link>
        <router-link to="/views/sample/directive/model/modelExample">v-model1</router-link>
        <router-link to="/views/sample/directive/model/modelExample2">v-model2</router-link>
        <br>
        <router-link to="/views/sample/observe/computedExample">computedEx</router-link>
        <router-link to="/views/sample/observe/watchExample">watchEx</router-link>
        <router-link to="/views/sample/observe/watchExample2">watchEx2</router-link>
        <router-link to="/views/sample/observe/compare">compare</router-link>
        <br>
        <br>
        <br>
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                id: 1,
                name: 'Kim tae ho',
                age: '25',
                title: 'Template Example',
                show: true
            }
        },
        methods: {
            nameChange() {
                this.name = this.name.split('').reverse().join('')
            }
        }
}
</script>

<style scoped>
/* CSS 스타일 */
    h1 {
        color: red;
    }
</style>