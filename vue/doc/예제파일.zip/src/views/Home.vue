<template>
    <div>
        <h1>{{ title }}</h1>
        <p>이름 : {{ name }}</p>
        <p>회사 : {{ company }}</p>
        <p>부서 : {{ dept }}</p>
        <p>직급 : {{ position }}</p>
        <button @click="updateName">click</button>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                title: 'This is Home page',
                name: 'Kim tae ho',
                company: 'sehyunict',
                dept: 'TD Division',
                position:'Senior staff'
            }
    },
    // beforeCreate() {
    //     // beforeCreate()에서는 data에 접근 불가능
    //     alert('beforeCreate : ' + this.name);
    // },
    // created() {
    //     // created()에서는 data에 접근 가능
    //     // DOM에 컴포넌트가 마운트 되지 않았기 때문에 $el사용은 불가능합니다.
    //     alert('created : '+ this.name);
    // },
    // beforeMount() {
    //     // 컴포넌트가 DOM에 추가되기 직전에 실행됩니다.
    //     alert('beforeMount')
    // },
    // mounted() {
    //     // 컴포넌트가 DOM에 추가될 때 실행되는 라이프 사이클 훅입니다.
    //     // $el을 사용하여 DOM에 접근할 수 있습니다.
    //     // 컴포넌트가 렌더링이 됬는지 보장된 상태에서 작업을 하려면 $nextTick을 사용해야 합니다.
    //     alert('mounted')
    // },
    // // DOM이 재 렌더링 되기 직전에 호출되는 라이프 사이클 훅입니다.
    // // 업데이트 된 값들을 가지고 있는 상태이기 때문에, 업데이트 된 값으로 다른 값들을 업데이트 할 수 있습니다.
    // beforeUpdate() {
    //     alert('beforeUpdate : ' + this.name)
    // },
    // // DOM이 재 렌더링 된 후 호출되는 라이프 사이클 훅입니다.
    // // DOM이 업데이트 된 후 호출되기 때문에 변경된 후의 DOM을 처리할 때 유용합니다.
    // updated() {
    //     alert('updated : ' + this.name)
    // },
    // // 이벤트 리스너 삭제 및 데이터 초기화에 많이 쓰임
    // beforeDestroy() {
    //     alert('beforeDestory')
    // },
    // // 인스턴스가 해제되고 난 직후에 destroyed 훅이 호출됨
    // // 인스턴스의 속성에 접근할 수 없고, 하위 인스턴스 역시 삭제됨
    // destroyed() {
    //     alert('destroyed')
    // },
    methods: {
        updateName() {
            this.name = 'hello';
        }
    }
}
</script>

<style scoped>
/* CSS 스타일 */
    h1 {
        color: red;
    }
</style>