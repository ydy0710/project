<template>
    <div>
        <h1>{{ count }}</h1><br>
        <!--computed의 calculated안의 함수를 실행시키기 위해서는 calculated를 실제로 출력해야 합니다.-->
        <!-- {{ calculated }} -->
        <button @click="count --">카운트 감소</button>
    </div>
</template>

<script>

export default {
    data() {
        return {
            count: 3,
            text: '변경 전입니다.'
        }
    },
    // computed는 이미 정의된 계산식에 따라 결과값을 반환할 때 사용
    computed: {
        calculated: function () {
            if(this.count === 2) {
                alert('값이 2가 되었습니다.')
            }
        }
    },
    // 어떤 특정 조건에서 함수를 실행시키기 위한 트리거로서 사용
    watch: {
        count: function (newVal) {
            if(newVal === 0) {
                alert('값이 0이 되었습니다.')
                this.count = 3
            }
        }
    }
}
</script>

<style scoped>

</style>