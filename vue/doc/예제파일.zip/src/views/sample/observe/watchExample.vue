<template>
    <div>
        <h2>watch Example</h2>
        <p>콘솔에서 message값을 바꿔주세요</p>
        <h2>원본 메세지: "{{ message }}"</h2>
        <h2>역순 메시지: "{{ reversedMessage }}"</h2>
    </div>
</template>

<script>

export default {
    data() {
        return {
            message: '안녕하세요',
            reversedMessage: ''
        }
    },
    // watch(감시자) - 지정한 대상의 값이 변경될 때마다 정의한 함수가 실행된다.
    watch: {
        // newVal과 oldVal을 인자로 받을 수 있다.
        // 감시하고 있는 대상의 변경된 값과 이전 값을 인자로 받는다.
        message: function(newVal, oldVal) {
            this.reversedMessage =  newVal.split('').reverse().join('')
        }
    }
}
</script>

<style scoped>

</style>