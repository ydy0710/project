<template>
    <div>
        <p>console창에서 message값을 바꿔보세요</p>
        <h2>원본 메세지: "{{ message }}"</h2>
        <h2>역순 메시지: "{{ reversedMessage }}"</h2>
    </div>
</template>

<script>

export default {
    data() {
        return {
            message: '안녕하세요'
        }
    },
    //computed - template내부에 선언된 computed중에서 해당 함수와 연결된 값이 바뀔 때만 해당 함수만을 실행한다.
    //methods -template내부에 선언된 methods중에서 update라이프사이클이 동작한(=아무 변수나 바뀐)다면 함수를 모두 실행한다.
    computed: {
        // reverseMessage함수는 message에 종속성을 갖는다.
        reversedMessage: function() {
            return this.message.split('').reverse().join('')
        }
    }
}
</script>

<style scoped>

</style>