<template>
    <div>
        <h2>watch Example</h2>
        <h1>{{ count }}</h1><br>
        <p>{{ text }}</p>
        <button @click="count --">카운트 감소</button>
    </div>
</template>

<script>

export default {
    data() {
        return {
            count: 3,
            text: '변경 전입니다.'
        }
    },
    // watch(감시자) - 지정한 대상의 값이 변경될 때마다 정의한 함수가 실행된다.
    watch: {
        // newVal과 oldVal을 인자로 받을 수 있다.
        // 감시하고 있는 대상의 변경된 값과 이전 값을 인자로 받는다.
        count: function (newVal, oldVal) {
        this.text = oldVal + '에서 ' + newVal + '로 변경되었습니다.'
    }
  }
}
</script>

<style scoped>

</style>