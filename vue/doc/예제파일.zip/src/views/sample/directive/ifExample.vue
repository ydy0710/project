<template>
    <div>
        <p>console에서 show값을 바꿔주세요</p>
            <!-- v-if 디렉티브는 v-if의 상태값이 true면 해당 태그를 렌더링하고
                 false인 경우 해당 태그를 렌더링하지 않는 디렉티브입니다.
                 v-else디렉티브는 v-if의 조건문이 만족하지 않는 경우 렌더링됩니다. -->
            <h1 v-if = "show">
                보입니다
            </h1>
            <h1 v-else>
                안보입니다
            </h1>
            <!-- v-if와 v-show의 차이점은 개발자도구로 확인하면 볼 수 있습니다.
                 v-if는 <!->표시로 아예 렌더링 되지 않고
                 v-show는 display:none 된 것을 확인할 수 있습니다. -->
            <h1 v-show = "show">v-show 테스트입니다.</h1>
    </div>
</template>

<script>

export default {
    data() {
        return {
            show: true
        }
    }
}
</script>

<style scoped>

</style>