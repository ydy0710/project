<template>
    <div>
        <br>
        <p>input 내용을 바꿔보세요</p>
        <input type = "text" v-model="name">
        <br>
        {{ name }}
    </div>
</template>

<script>

export default {
    data() {
        return {
            name: 'taeho'
        }
    }
}
</script>

<style scoped>

</style>