<template>
    <div>
        <br>
        <h3><input type = "checkbox" v-model="feels">Change</h3>
        <img :src="feels ? good : bad"/>
    </div>
</template>

<script>
import good from '@/assets/good.png'
import bad from '@/assets/bad.png'

export default {
    data() {
        return {
            feels: true,
            good: good,
            bad: bad
        }
    }
}
</script>

<style scoped>
img {
    width : 300px;
    height : 300px;
}
</style>