<template>
    <div>
        <!-- v-once 디렉티브는 HTML코드로 출력이 된 후에
             어떤 후처리가 있더라도 처음 출력값을 유지시킬 때 사용합니다. -->
        <p>console에서 title값을 확인해보세요</p>
        <h1 v-once>{{ title }}</h1>
        <h2>{{ titleChange() }}</h2>
    </div>
</template>

<script>

export default {
    data() {
        return {
            title : '안녕하세요'
        }
    },
    methods: {
        // titleChange 호출 시 title 변경
        titleChange() {
            this.title = '반갑습니다'
            return this.title
        }
    }
}
</script>

<style scoped>

</style>