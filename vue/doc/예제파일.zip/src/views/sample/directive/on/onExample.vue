<template>
    <div>
        <p>버튼 클릭 이벤트</p>
        <h2>{{ number }}</h2>
        <!-- v-on 디렉티브는 이벤트 리스너의 역할을 한다.
             v-on:이벤트이름="메소드이름" 형식으로 사용한다. -->
        <button v-on:click="rollDice()">{{ btn }}</button>
        <!-- v-on 디렉티브는 @로 대체해서 사용할수 있습니다. -->
        <button @click="nameChange()">버튼 바꾸기</button>
    </div>
</template>

<script>

export default {
    data() {
        return {
            btn: '주사위 던지기',
            number: 0 //주사위 숫자를 저장할 변수
        }
    },
     methods: {
        //주사위를 던졌을 때 실행되는 함수
        rollDice() {
            var random = Math.floor(Math.random() * (6)) + 1;
            this.number = random;
        },
        nameChange() {
            this.btn = this.btn.split('').reverse().join('')
        }
    }
}
</script>

<style scoped>

</style>