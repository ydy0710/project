<template>
    <div>
        <p>버튼 클릭 이벤트 함수 인자값 받기</p>
       <h2>{{ count }}</h2>
        <!-- event Object 뿐아니라 임의로 생성한 값도 인수로 받아
             함수에서 인자로 사용할수 있습니다. -->
        <button v-on:click="addCount(2)">+2</button>
    </div>
</template>

<script>

export default {
    data() {
        return {
           count: 0
        }
    },
    methods: {
        addCount(number) {
            this.count = this.count + number;
        }
    }
}
</script>

<style scoped>

</style>