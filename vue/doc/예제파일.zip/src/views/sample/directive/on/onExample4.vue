<template>
    <div>
        <!-- keyup이벤트 -->
        <p>내용 입력후에 엔터키를 눌러주세요(keyUp)</p>
        <span>ID</span><input type = "text" placeholder="아이디를 입력하세요"/>
        <br>
        <span>PW</span><input v-on:keyup.enter="login()" type = "text" placeholder="비밀번호를 입력하세요"/>
        <div>
            <button @click="login()">login</button>
        </div>
    </div>
</template>

<script>

export default {
    data() {
        return {
           count: 0
        }
    },
    methods: {
        login() {
            alert('로그인 완료!')
        }
    }
}
</script>

<style scoped>
div {
    width: 400px;
    height: 300px;
    margin: 0 auto;
    margin-top : 30px;
}
div > span {
    width : 40px;
    height : 20px;
    margin-top : 13px;
    text-align : left;
    float:left;
}
div > input {
    width : 300px;
    height : 20px;
    margin : 10px;

}
</style>