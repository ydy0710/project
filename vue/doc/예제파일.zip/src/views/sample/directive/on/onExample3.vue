<template>
    <div>
        <p>마우스무브 이벤트</p>
        <p>{{ count }}</p>
        <!-- mousemove 이벤트 -->
        <h2 v-on:mousemove="addCount()">마우스를 올려주세요</h2>
    </div>
</template>

<script>

export default {
    data() {
        return {
           count: 0
        }
    },
    methods: {
        addCount() {
            this.count++
        }
    }
}
</script>

<style scoped>

</style>