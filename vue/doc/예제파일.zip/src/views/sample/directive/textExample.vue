<template>
    <div>
        <h2>v-text Example</h2>
        <!-- Vue 인스턴스의 test값을 엘리먼트의 내부 값으로 설정 -->
        <span v-text = "test"></span>
        <br/>
        <!-- html 태그자체가 텍스트형태로 렌더링 되기 때문에
             html 태그를 사용할때는 v-html을 사용해야합니다. -->
        <span v-text = "html"></span>
    </div>
</template>

<script>

export default {
    data() {
        return {
            test: 'v-text 테스트입니다.',
            html: '<i>v-text html태그 테스트입니다.</i>'
        }
    }
}
</script>

<style scoped>

</style>