<template>
    <div>
        <h1>{{ title }}</h1>
        <p>console에서 feels값을 false로 바꿔보세요</p>
        <!-- 삼항 연산자를 사용하여 bind의 값을 바꿀수 있습니다.
             console에서 app.feels의 값을 바꾸면 img가 바뀌는것을 확인할 수 있습니다. -->
        <img :src="feels ? good : bad"/>
    </div>
</template>

<script>
import good from '@/assets/good.png'
import bad from '@/assets/bad.png'

export default {
    data() {
        return {
            title:'v-bind Example',
            feels: true,
            good: good,
            bad: bad
        }
    }
}
</script>

<style scoped>
img {
    width : 300px;
    height : 300px;
}
</style>