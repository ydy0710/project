<template>
    <div>
        <h1>{{ title }}</h1>
        <!-- v-bind 디렉티브를 사용하면 html 속성에 
             Vue 인스턴스 내의 값을 사용할수 있습니다. -->
        <img v-bind:src="good"/>
        <!-- v-bind는 사용자의 편의를 위해
             :src와 같이 약어를 사용할 수 있습니다.
             : + 속성명 ex) :src, :href...-->
        <img :src="bad"/>
    </div>
</template>

<script>
import good from '@/assets/good.png'
import bad from '@/assets/bad.png'

export default {
    data() {
        return {
            title:'v-bind Example',
            good: good,
            bad: bad
        }
    }
}
</script>

<style scoped>
img {
    width : 300px;
    height : 300px;
}
</style>