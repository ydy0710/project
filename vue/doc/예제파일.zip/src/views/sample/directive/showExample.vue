<template>
    <div>
        <p>console에서 show값을 false로 바꿔보세요</p>
        <h2>v-show Test입니다.</h2>
        <!-- v-show 디렉티브는 해당 엘리먼트를 보여줄지 말지
             true/false 값으로 지정할 수 있습니다.
             console에서 show의 값을 바꾸면 span이 사라지는것을 확인할 수 있습니다. -->
        <h2 v-show="show" v-text="title"></h2>
    </div>
</template>

<script>

export default {
    data() {
        return {
            title: '사라집니다.',
            show: true
        }
    }
}
</script>

<style scoped>

</style>