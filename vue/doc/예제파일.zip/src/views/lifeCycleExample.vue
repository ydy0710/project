<template>
<!-- template - html 코드입력(뷰 컴포넌트의 표현단) -->
    <div>
        <h1 id="title">Life Cycle Example</h1>
        <!-- 등록한 컴포넌트는 html 태그처럼 사용할 수 있습니다. -->
        <!-- <test title="Home page title" name="homeName"></test> -->
            <!-- 컴포넌트에서 v-model 사용시
            value를 child 컴포넌트에 props로 내려준다. -->
            <inputField v-model="name"></inputField>
            <button @click="updateName">Submit</button>
            {{ name }}
            <br>
            <img :src="img">
    </div>
</template>

<script>

var title = document.getElementById('title');
//자바스크립트(뷰 컴포넌트 내용)

// 컴포넌트 import
import inputField from '@/components/inputField.vue';
import lifeCycleConsole from '@/assets/lifeCycleConsole.png'

// 페이지 옵션
export default {
    name: 'lifeCycle',
    components: {
      inputField 
    },
    data() {
        return {
            name: 'kimtaeho',
            img: lifeCycleConsole
        }
    },
    beforeCreate() {
        // beforeCreate()에서는 data에 접근 불가능
        alert('beforeCreate : ' + this.name);
    },
    created() {
        // created()에서는 data에 접근 가능
        // DOM에 컴포넌트가 마운트 되지 않았기 때문에 $el사용은 불가능합니다.
        alert('created : '+ this.name);
    },
    beforeMount() {
        // 컴포넌트가 DOM에 추가되기 직전에 실행됩니다.
        alert('beforeMount')
    },
    mounted() {
        // 컴포넌트가 DOM에 추가될 때 실행되는 라이프 사이클 훅입니다.
        // $el을 사용하여 DOM에 접근할 수 있습니다.
        // 컴포넌트가 렌더링이 됬는지 보장된 상태에서 작업을 하려면 $nextTick을 사용해야 합니다.
        alert('mounted')
    },
    // DOM이 재 렌더링 되기 직전에 호출되는 라이프 사이클 훅입니다.
    // 업데이트 된 값들을 가지고 있는 상태이기 때문에, 업데이트 된 값으로 다른 값들을 업데이트 할 수 있습니다.
    beforeUpdate() {
        alert('beforeUpdate : ' + this.name)
    },
    // DOM이 재 렌더링 된 후 호출되는 라이프 사이클 훅입니다.
    // DOM이 업데이트 된 후 호출되기 때문에 변경된 후의 DOM을 처리할 때 유용합니다.
    updated() {
        alert('updated : ' + this.name)
    },
    methods: {
        updateName() {
            this.name = 'hello';
        }
    }
}
</script>

<style scoped>
h1 {
    color: green;
}

img {
    width: 400px;
    height: 300px; 
}
</style>