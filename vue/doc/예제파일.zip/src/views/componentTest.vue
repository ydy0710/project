<template>
    <div>
        <h1>{{ title }}</h1>
        <global></global>
        <local></local>
    </div>
</template>

<script>
import local from '../components/localComponent.vue';

export default {
    components: {
        local
    },
    data() {
        return {
            title: 'Component Test'
        }
    }
}
</script>

<style scoped>
h1 {
    color: green;
}
</style>