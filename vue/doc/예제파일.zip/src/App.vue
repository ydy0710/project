<template>
  <div id="app">
    <div id = "nav">
    <!-- 네비게이션을 위해 router-link 컴포넌트를 사용합니다. -->
    <!-- <router-link> 태그는 a태그로 렌더링됩니다. -->
      <router-link to="/">Home!</router-link>
      <router-link to="/componentTest">ComponentTest!</router-link>
      <router-link to="/templateExam">template!</router-link>
      <!-- <router-link to="/slot">slot!</router-link> -->
      <router-link to="/lifeCycleExample">lifeCycle!</router-link>
    </div>
    <!-- 현재 라우트에 맞는 컴포넌트 렌더링 -->
    <router-view/>
    <!-- <img src="./assets/logo.png"> -->
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color :#2c3e50;
}

#nav a.router-link-exact-active {
  color:#42b983;
}
</style>
