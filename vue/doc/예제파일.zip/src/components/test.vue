<template>
    <div>
        <!-- slot은 컴포넌트의 재사용성을 높여주는 기능입니다.
             특정 컴포넌트에 등록된 하위 컴포넌트의 마크업을 확장하거나
             재정의 할 수 있습니다. -->
        <h1>Header</h1>
        <slot name="header" :myName="myName"></slot>
        <h1>Contents</h1>
        <slot name = "body"></slot>
    </div>
</template>

<script>
export default {
    props: {
        title :{
            // props에 받을 데이터의 타입 설정
            type: String,
            // 필요 여부 설정 true:반드시 필요 / false:필요X
            required: false,
            // 기본값 설정
            default: 'default title'
        },
        name :{
            type: String,
            required: false,
            default: 'default name'
        }
    },
    data() {
        return {
            myName: 'kimtaeho',
        }
    },
    methods: {
        // props에서 사용하는 값은 부모 페이지에서만 바꿔야합니다.
        updateName() {
             this.name = 'name change test'
        }
    }
}
</script>

<style scoped>

</style>