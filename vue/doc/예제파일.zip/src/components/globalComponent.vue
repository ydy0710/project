<template>
    <div>
        <h1>{{ title }}</h1>
        <button @click="titleChange">click</button>
    </div>

    
</template>

<script>
    export default {
        name: 'globalComponent',
        data() {
            return {
                title: '글로벌 컴포넌트입니다.'
            }
        },
        methods: {
            titleChange() {
                this.title = '글로벌 컴포넌트 테스트입니다.'
            }
        }
    }
</script>

<style>

</style>