<template>
    <label for="">Name
        <!-- 부모창에서 컴포넌트에 v-model을 사용하는 경우
             input을 이벤트로 사용합니다. -->
        <!-- input 태그에서 값이 입력되면 인풋 태그에서 
             input 이벤트가 발생하고 updateInput 메서드가 실행됩니다.  -->
        <input type="text" :value="value"
               @input="updateInput"/>
    </label>
</template>

<script>
    export default {
        props: {
            value: {
                type: String,
                required: true
            }
        },
        methods: {
            // updateInput 메서드에서 인풋 태그에 입력된 값을 
            // 상위컴포넌트에 input 이벤트로 올려보냅니다.
            updateInput(e) {
                console.log(e.target.value);
                this.$emit('input', e.target.value);
            }
        }
    }
</script>