<template>
    <div>
        <h1>{{ title }}</h1>
        <button @click="titleChange">click</button>
    </div>
</template>

<script>
    export default {
        name: 'localComponent',
        data() {
            return {
                title: '로컬 컴포넌트입니다.'
            }
        },
        methods: {
            titleChange() {
                this.title = '로컬 컴포넌트 테스트입니다.'
            }
        }
    }
</script>

<style>

</style>