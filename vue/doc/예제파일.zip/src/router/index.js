import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/views/Home'
import about from '@/views/slot'
import templateExam from '@/views/templateExample'
import lifeCycle from '@/views/lifeCycleExample'
import componentTest from '@/views/componentTest'
import bindEx1 from '@/views/sample/directive/bind/bindExample'
import bindEx2 from '@/views/sample/directive/bind/bindExample2'
import forEx from '@/views/sample/directive/forExample'
import htmlEx from '@/views/sample/directive/htmlExample'
import textEx from '@/views/sample/directive/textExample'
import ifEx from '@/views/sample/directive/ifExample'
import showEx from '@/views/sample/directive/showExample'
import modelEx1 from '@/views/sample/directive/model/modelExample'
import modelEx2 from '@/views/sample/directive/model/modelExample2'
import onEx1 from '@/views/sample/directive/on/onExample'
import onEx2 from '@/views/sample/directive/on/onExample2'
import onEx3 from '@/views/sample/directive/on/onExample3'
import onEx4 from '@/views/sample/directive/on/onExample4'
import onceEx from '@/views/sample/directive/onceExample'
import computedEx from '@/views/sample/observe/computedExample'
import watchEx from '@/views/sample/observe/watchExample'
import watchEx2 from '@/views/sample/observe/watchExample2'
import compare from '@/views/sample/observe/compare'


//플러그인을 실행하기 위해서 칠요한 코드
Vue.use(Router)
  // routes: Vue Router에 의해서 컨트롤되는 페이지의 정보를 담는 것
  var routes = [
    {
      path: '/', // path - 브라우저에서 사용하는 url주소
      name: 'home', // 페이지에서 사용할 이름
      component: Home // 컴포넌트 지정
    },
    {
      path: '/componentTest',
      name: 'componentTest',
      component: componentTest
    },
    {
      path: '/slot',
      name: 'slot',
      component: about
    },
    {
      path: '/templateExam',
      name: 'hello',
      component: templateExam,
      children: [
        {
          path: '/views/sample/directive/bind/bindExample',
          name: 'bindEx1',
          component: bindEx1
        },
        {
          path: '/views/sample/directive/bind/bindExample2',
          name: 'bindEx2',
          component: bindEx2
        },
        {
          path: '/views/sample/directive/forExample',
          name: 'forEx',
          component: forEx
        },
        {
          path: '/views/sample/directive/htmlExample',
          name: 'htmlEx',
          component: htmlEx
        },
        {
          path: '/views/sample/directive/textExample',
          name: 'textEx',
          component: textEx
        },
        {
          path: '/views/sample/directive/ifExample',
          name: 'ifEx',
          component: ifEx
        },
        {
          path: '/views/sample/directive/showExample',
          name: 'showEx',
          component: showEx
        },
        {
          path: '/views/sample/directive/model/modelExample',
          name: 'modelEx1',
          component: modelEx1
        },
        {
          path: '/views/sample/directive/model/modelExample2',
          name: 'modelEx2',
          component: modelEx2
        },
        {
          path: '/views/sample/directive/on/onExample',
          name: 'onEx1',
          component: onEx1
        },
        {
          path: '/views/sample/directive/on/onExample2',
          name: 'onEx2',
          component: onEx2
        },
        {
          path: '/views/sample/directive/on/onExample3',
          name: 'onEx3',
          component: onEx3
        },
        {
          path: '/views/sample/directive/on/onExample4',
          name: 'onEx4',
          component: onEx4
        },
        {
          path: '/views/sample/directive/onceExample',
          name: 'onceEx',
          component: onceEx
        },
        {
          path: '/views/sample/observe/computedExample',
          name: 'computedEx',
          component: computedEx
        },
        {
          path: '/views/sample/observe/watchExample',
          name: 'watchEx',
          component: watchEx
        },
        {
          path: '/views/sample/observe/watchExample2',
          name: 'watchEx2',
          component: watchEx2
        },
        {
          path: '/views/sample/observe/compare',
          name: 'compare',
          component: compare
        }
      ]
    },
    {
      path: '/lifeCycleExample',
      name: 'lifeCycle',
      component: lifeCycle
    },
  ]

  //router 인스턴스 생성
  var router = new Router({
    mode: 'history', // URL의 해쉬 값 제거속성, url 이동시 세션기록상태를 추가.
    routes: routes // 라우팅할 URL과 컴포넌트 값 지정
  })

  //VueRouter로 인스턴스를 생성하고 export default로 꺼냄.
export default router
